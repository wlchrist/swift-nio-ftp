//
//  ContentView.swift
//  rewrite-bluelink
//
//  Created by Warren Christian on 6/2/25.
//

import SwiftUI

struct MainView: View {
	
	init() {
		 // Modify the badge Color
		 UITabBarItem.appearance().badgeColor = .green
	}
			  var body: some View {
				  TabView {
					  RemoteDeviceView()
				  }
			  }
        }




#Preview {
    MainView()
}
