//
//  SplashView.swift
//
//  Created by Chris Sargeant on 9/2/24.
//

import SwiftUI

struct SplashView: View {
    var body: some View {
        ZStack {
            Rectangle()
                .background(.black)
                .foregroundColor(.constantSelBlue)
            Image(.sel)
                .resizable()
                .scaledToFit()
                .padding(85)
                .foregroundColor(.white)
        }
        .frame(alignment: .center)
        .ignoresSafeArea()
    }
}

#Preview {
    SplashView()
}
