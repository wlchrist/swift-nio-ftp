//
//  UPnP.swift
//  rewrite-bluelink
//
//  Created by Warren Christian on 6/4/25.
//

import Foundation
import NIO

/// Immediately flushes a message, waits, then closes the pipeline after a specified time.
/// No model associated with this, as this service is quickly disposed of and serves one purpose.
final class IPDiscoveryService: @unchecked Sendable {
	
	var eventLoopGroup = MultiThreadedEventLoopGroup(numberOfThreads: 1)
	
	// handlers
	var channelReadHandler = IPDiscoverHandler()
	
	// data from pipeline
	var currentResponse: String {
		return channelReadHandler.currentResponse
	}
	var autoIP: String {
		return self.channelReadHandler.autoIP
	}
	var usbIP = getUSBInterfaceIP() ?? ""
	
	func getIP(waitFor: useconds_t) async throws {
		do {
			let bootstrap = DatagramBootstrap(group: self.eventLoopGroup)
				.channelOption(ChannelOptions.socketOption(.so_reuseaddr), value: 1)
				.channelInitializer { [self] channel in
					channel.pipeline.addHandlers([
						channelReadHandler
					])
				}
			
			let messageString = """
				 M-SEARCH * HTTP/1.1
				 HOST: 239.255.255.250:1900
				 ST: upnp:rootdevice
				 Man: "ssdp:discover"
				 MX: 3
				 """
			
			let channel = try await bootstrap
				.bind(host: getUSBInterfaceIP() ?? "0.0.0.0", port: 1900)
				.get()
			
			let remoteDest = try! SocketAddress(ipAddress: "239.255.255.250", port: 1900)
			let outData = channel.allocator
				.buffer(string: messageString)
			
			let envelope = AddressedEnvelope(remoteAddress: remoteDest, data: outData)
			try await channel.writeAndFlush(envelope)
			usleep(waitFor)
			eventLoopGroup = MultiThreadedEventLoopGroup(numberOfThreads: 1)
		} catch {
			print(error.localizedDescription)
		}
	}
	

class IPDiscoverHandler: ChannelInboundHandler {
		
		public typealias InboundIn = AddressedEnvelope<ByteBuffer>
		public typealias InboundOut = AddressedEnvelope<ByteBuffer>
		public typealias OutboundOut = AddressedEnvelope<ByteBuffer>
		var currentResponse = ""
		var autoIP = ""
		
		func channelActive(context: ChannelHandlerContext) {
				context.fireChannelActive()
		}
		
		func channelRead(context: ChannelHandlerContext, data: NIOAny) {
			let envelope = unwrapInboundIn(data)
			var inBuff = envelope.data
			let str = inBuff.readString(length: inBuff.readableBytes) ?? ""
			currentResponse = str
			autoIP = envelope.remoteAddress.ipAddress ?? ""
			print(autoIP)
			print(currentResponse)

		}
	}
}

func IPDiscoveryResponseParser(_ response: String) -> String {
	 let regex = try! NSRegularExpression(pattern: #"(\d{1,3}\.){3}\d{1,3}"#)
	 if let match = regex.firstMatch(in: response, range: NSRange(response.startIndex..., in: response)) {
		  let ipRange = Range(match.range, in: response)!
		  let ip = String(response[ipRange])
		  return ip
	 }
	 return "Could not parse response: \(response)"
}

/// Grabs the APIPA address of your local network interface
func getUSBInterfaceIP() -> String? {
	 var ifaddr: UnsafeMutablePointer<ifaddrs>?
	 guard getifaddrs(&ifaddr) == 0, let firstAddr = ifaddr else { return nil }
	 defer { freeifaddrs(ifaddr) }

	 var candidates: [(String, String)] = []
	 for ptr in sequence(first: firstAddr, next: { $0.pointee.ifa_next }) {
		  let interface = ptr.pointee
		  let name = String(cString: interface.ifa_name)
		  let flags = Int32(interface.ifa_flags)

		  guard interface.ifa_addr.pointee.sa_family == UInt8(AF_INET),
				  (flags & (IFF_UP|IFF_RUNNING)) == (IFF_UP|IFF_RUNNING)
		  else { continue }

		  var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
		  let result = getnameinfo(interface.ifa_addr, socklen_t(interface.ifa_addr.pointee.sa_len),
											&hostname, socklen_t(hostname.count),
											nil, 0, NI_NUMERICHOST)

		  guard result == 0 else { continue }
		  let ip = String(cString: hostname)
		 
		 // Exclude loopback, filter for autoIP
		  guard ip != "127.0.0.1", ip.hasPrefix("169.") else {continue}
		  
		  if name.hasPrefix("en") {
				candidates.append((name, ip))
		  }
		  
	 }
	 return candidates.first?.1
}
