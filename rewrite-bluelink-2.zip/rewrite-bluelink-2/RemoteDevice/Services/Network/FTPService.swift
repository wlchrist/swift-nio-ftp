//
//  NIO.swift
//  rewrite-bluelink
//
//  Created by Warren Christian on 6/2/25.
//

import Foundation
import SwiftUI
import NIO
import RegexBuilder

/// Stores data for our pipeline before bootstrapping the the connection. Using convenience initializers, as this separates concerns within our service/model/view.
/// Should not be thought of as distinct from service, but rather, a dependency required for our service to execute properly
@Observable
final class PipelineManager {
	
	var eventLoop: MultiThreadedEventLoopGroup
	var controlBootstap: ClientBootstrap
	var dataBootstrap: ClientBootstrap
	var currentMessage: String
	var currentResponseCode: Int
	var files: [FileInfo]
	
	init(eventLoop: MultiThreadedEventLoopGroup, controlBootstrap: ClientBootstrap, dataBootstrap: ClientBootstrap, currentMessage: String, currentResponseCode: Int, files: [FileInfo]) {
		self.eventLoop = eventLoop
		self.controlBootstap = controlBootstrap
		self.dataBootstrap = dataBootstrap
		self.currentMessage = currentMessage
		self.currentResponseCode = currentResponseCode
		self.files = files
	}
	
	convenience init() {
		let eventLoop = MultiThreadedEventLoopGroup(numberOfThreads: System.coreCount)
		let controlBootstrap = ClientBootstrap(group: eventLoop)
		let dataBootstrap = ClientBootstrap(group: eventLoop)
		let currentMessage = ""
		let currentResponseCode = 0
		let files = [FileInfo(name: "")]
		self.init(eventLoop: eventLoop, controlBootstrap: controlBootstrap, dataBootstrap: dataBootstrap, currentMessage: currentMessage, currentResponseCode: currentResponseCode, files: files)
	}
	
	 internal func changeEmitter(responseCode: Int) -> Int {
		print("changeEmitter fired with \(responseCode)")
		return responseCode
	}
}

/// FTP service. Creates an instance of `PipelineManager`.
/// Responsible for starting the connection and keeping track of FTP-specific details, such as logins, response code dispatching, and creating both the control and data channel.
/// Data channels are separated into their respective use-case since they are closed by the FTP server once a successful data retreival event has completed.
@preconcurrency
class FTPService: @unchecked Sendable {
	
	var host: String?
	var port: Int?
	var pipelineManager = PipelineManager()
	private var controlChannel: Channel?
	private var dataChannel: Channel?
	var currentAction: UserAction = .idle
	
	var serverResponseMessage: String {
		return pipelineManager.currentMessage
	}
	var serverResponseCode: Int {
		return pipelineManager.currentResponseCode
	}
	var files: [FileInfo] {
		return pipelineManager.files
	}
	
	private func stringToBuffer(_ str: String) -> ByteBuffer {
		return ByteBuffer(string: "\(str)" + "\r\n")
	}
	
	func connectControlChannel(device: SELDeviceModel) async throws {
		self.host =  device.ip
		self.port =  device.port
		controlChannel = try await pipelineManager.controlBootstap.channelInitializer { [self] channel in
			channel.pipeline.addHandlers([
				ChannelReadHandler(manager: pipelineManager, service: self)
			])
		}.connect(host: self.host ?? "", port: self.port ?? 21).get()
	}
	
	func connectFileListChannel(ip: String, port: Int) async throws {
		dataChannel = try await pipelineManager.dataBootstrap.channelInitializer { [self] channel in
			channel.pipeline.addHandlers([
				FileListReadHandler(manager: pipelineManager)
			])
		}.connect(host: ip, port: port).get()
	}
	
	func connectDownloadChannel(ip: String, port: Int) async throws {
		dataChannel = try await pipelineManager.dataBootstrap.channelInitializer{ [self] channel in
			channel.pipeline.addHandlers([
				DownloadHandler(manager: pipelineManager)
			])
		}.connect(host: ip, port: port).get()
	}
	
	func send(_ str: String) {
		let strBuff = ByteBuffer(string: str)
		print("Sent: \(str.debugDescription)")
		controlChannel?.eventLoop.scheduleTask(in: .milliseconds(150), { [self] in
			Task { @MainActor in
				controlChannel?.writeAndFlush(strBuff)
			}
		})
	}
	
	func listFiles() {
		
	}
	
	func changeDirectory(_ directory: String) async {
		send("CWD \(directory)")
	}
	
	func login(username: String, password: String) {
		send("USER \(username)\r\n")
		send("PASS \(password)\r\n")
	}
}

	final class ChannelReadHandler: ChannelInboundHandler {
		var manager: PipelineManager
		var service: FTPService
		
		init(manager: PipelineManager, service: FTPService) {
			self.manager = manager
			self.service = service
		}
		
		public typealias InboundIn = ByteBuffer
		public typealias InboundOut = ByteBuffer
		public typealias OutboundOut = ByteBuffer
		
		private func getResponseCode(_ from: String) -> Int {
			return from.components(separatedBy: " ").compactMap{Int($0)}[0]
		}
		
		func strToBuff(context: ChannelHandlerContext, _ string: String) -> ByteBuffer {
			return context.channel.allocator.buffer(string: string)
		}
		
		func channelActive(context: ChannelHandlerContext) {
			print("Remote peer connected: \(context.remoteAddress?.ipAddress ?? "")")
			print("Port: \(context.remoteAddress?.port ?? 0)")
		}
		
		func channelRead(context: ChannelHandlerContext, data: NIOAny) {
			let inBuff = unwrapInboundIn(data)
			guard let str = inBuff.getString(at: 0, length: inBuff.readableBytes) else {return}
			print(str.debugDescription)
			let responseCode = getResponseCode(str)
			manager.changeEmitter(responseCode: responseCode)
			manager.currentMessage = str
			manager.currentResponseCode = getResponseCode(str)
			actionInvoker(responseCode: responseCode, action: service.currentAction, context: context)
		}
		
		func actionInvoker(responseCode: Int, action: UserAction, context: ChannelHandlerContext) {
			
			let dataTransferEventLoop = MultiThreadedEventLoopGroup(numberOfThreads: System.coreCount)
			
			enum List: Int {
				case passive = 227
				case fileStatusOK = 150
			}
			
			if action == .list {
				switch List(rawValue: responseCode) {
				case .passive:
					
					Task {
						do {
							try await ClientBootstrap(group: dataTransferEventLoop).channelInitializer { channel in
								channel.pipeline.addHandler(FileListReadHandler(manager: self.manager))
							}.connect(host: context.remoteAddress?.ipAddress ?? "", port: passivePortCalculator(manager.currentMessage)).get()
						} catch {
							print(error.localizedDescription)
						}
					}
				case .fileStatusOK:
					service.send("LIST\r\n")
					break
				default:
					break
				}
			}
			
		}
	}

final class FileListReadHandler: ChannelInboundHandler {
	
	public typealias InboundIn = ByteBuffer
	public typealias Inboundout = ByteBuffer
	
	var currentString = ""
	var manager: PipelineManager
	
	init(manager: PipelineManager) {
		self.manager = manager
	}
	
	func channelActive(context: ChannelHandlerContext) {
		print("Channel active on: \(context.remoteAddress?.port ?? 0)")
	}
	
	func channelRead(context: ChannelHandlerContext, data: NIOAny) {
		let inBuff = unwrapInboundIn(data)
		guard let str = inBuff.getString(at: 0, length: inBuff.readableBytes) else {return}
		currentString.append(contentsOf: str)
		manager.files = buildFileStruct(str)
		print(str)
	}
	
	/// Takes in raw string output of a "LIST" command and returns a list of `FileInfo` structs
	fileprivate func buildFileStruct(_ listOutput: String) -> [FileInfo] {
		var fileInfoArr = [FileInfo]()
		let fileListRegex = FileListInfo()
		
		for file in fileListRegex.fileListPattern(listOutput) {
			fileInfoArr.append(FileInfo(name: file))
			
		}
		return fileInfoArr
	}
}

final class DownloadHandler: ChannelInboundHandler {
	
	public typealias InboundIn = ByteBuffer
	public typealias InboundOut = ByteBuffer
	var manager: PipelineManager
	
	init(manager: PipelineManager) {
		self.manager = manager
	}
	
	func channelActive(context: ChannelHandlerContext) {
		print("Channel active on: \(context.remoteAddress?.port ?? 0)")
	}
	
	func channelRead(context: ChannelHandlerContext, data: NIOAny) {
		let inBuff = unwrapInboundIn(data)
		guard let str = inBuff.getString(at: 0, length: inBuff.readableBytes) else {return}
		print(str)
	}
}

/// Conveniences below

public func passivePortCalculator(_ serverResponse: String) throws -> Int {
	
	let defaultPort = 20
	guard let port = try? /\(.*\)/.firstMatch(in: serverResponse)?
		.output.replacingOccurrences(of: "[()]", with: "", options: [.regularExpression])
		.components(separatedBy: ",") else {return defaultPort}
	
	let passiveOctets = port.suffix(2).compactMap { Int($0) }
	return passiveOctets[0] * 256 + passiveOctets[1]
}

struct FileListInfo {
	func fileListPattern(_ input: String) -> [String] {
		var fileList = [String]()
		let fileFolderRegex =
		Regex {
			TryCapture {
				/(?m)([\w.:-]+$)/
			} transform: {
				String($0)
			}
		}
		let matches = input.matches(of: fileFolderRegex)
		for match in matches {
			fileList.append(match.output.1)
		}
		return fileList
	}
	
	func filePermissionsPattern(_ input: String) -> [String] {
		var fileList = [String]()
		let fileFolderRegex =
		Regex {
			TryCapture {
				/(?m)(^[drw-]+)/
			} transform: {
				String($0)
			}
		}
		let matches = input.matches(of: fileFolderRegex)
		for match in matches {
			fileList.append(match.output.1)
		}
		return fileList
	}
}

enum UserAction {
	case idle
	case list
	case download
	case disconnect
}
