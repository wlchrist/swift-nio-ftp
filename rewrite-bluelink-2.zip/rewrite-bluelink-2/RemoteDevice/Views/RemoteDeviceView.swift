//
//  RemoteDeviceViewa.swift
//  rewrite-bluelink
//
//  Created by Warren Christian on 6/3/25.
//

import SwiftUI
import NIO

struct RemoteDeviceView: View {
	// Models
	@State private var ftpModel = FTPModel()
	@State private var upnpModel = UPnPModel(upnpService: IPDiscoveryService())
	@State private var remoteDeviceModel = RemoteDeviceModel()
	
	// State tracking
	@State private var mode = 0
	
	var body: some View {
		 NavigationStack {
			  VStack {
					if self.remoteDeviceModel.isConnected {
						 // TODO: Switch to a local list if mode is send
						 RemoteDeviceListFilesView()
							.environment(ftpModel)
							.environment(remoteDeviceModel)
						 
					} else {
						 RemoteDeviceLoginView()
							.environment(ftpModel)
							.environment(upnpModel)
							.environment(remoteDeviceModel)
					}
			  }.toolbar {
					// Implement proper disconnect
					ToolbarItem {
						 if remoteDeviceModel.isConnected {
							 Button(action: disconnectFromDevice) {
								 Image(systemName: "network.slash")
							 }
						 }
					}
					
					// Add Picker for mode
					ToolbarItem(placement: .principal) {
						 if remoteDeviceModel.isConnected {
							  Picker("Mode", selection: $mode) {
									Text("Read").tag(0)
									Text("Send").tag(1)
							  }
							  .pickerStyle(.segmented)
						 }
					}
			  }
		 }
	}
	private func disconnectFromDevice() {
		 remoteDeviceModel.isConnected = false
		}
	}


#Preview {
    RemoteDeviceView()
}
