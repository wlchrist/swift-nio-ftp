
import SwiftUI

struct RemoteDeviceFileContentView: View {
	@Environment(FTPModel.self) private var ftpModel
	
	// File selection
	@State var selectedFile: String
	
	// Alerts
	@State private var alertIsPresented = false
	@State private var alertMessage: String?
	@State private var alertTitle: String?
	
	// Text
	@State var text = "Hello this is a test of the new text editor view"
	var body: some View {
		ScrollView {
			 VStack {
				  TextEditor(text: $text)
						.multilineTextAlignment(.leading)
						.font(Font.system(size: 12).monospaced())
						.frame(maxWidth: .infinity, alignment: .leading)
						.padding()
			 }
			 .padding(.horizontal)
			 .navigationTitle(selectedFile)
		}.onAppear {
			 // Load file
			ftpModel.selectedFile = selectedFile
		}
		.toolbar {
			 ToolbarItem {
				  Button("Save thing") {
						Image(systemName: "square.and.arrow.down")
				  }.alert("Saved!", isPresented: $alertIsPresented) {
						Button("OK", role: .cancel) { alertIsPresented = false }
				  } message: {
						Text(alertMessage ?? "")
				  }
				  
			 }
		}
   }
	
	fileprivate func readFile(_ name: String) {
		
	}
	
	fileprivate func saveFile(_ name: String) {
		let fileManager = FileManager.default
		let documentsDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
		let outputFileName = documentsDirectory.appendingPathComponent("foo.txt")
		
	}
}

#Preview {
	 RemoteDeviceFileContentView(selectedFile: "")
}
