//
//  RemoteDeviceLoginView.swift
//  rewrite-bluelink
//
//  Created by Warren Christian on 6/4/25.
//

import SwiftUI

struct RemoteDeviceLoginView: View {
	
	// Models
	@Environment(FTPModel.self) private var ftpModel
	@Environment(UPnPModel.self) private var upnpModel
	@Environment(RemoteDeviceModel.self) private var remoteDeviceModel
	
	// Login information
	@State var username = ""
	@State var password = ""
	
	// Device list
	@State var remoteDeviceList: [SELDeviceModel] = [
		SELDeviceModel(name: "9 Series", ip: "192.168.1.20", port: 21),
		SELDeviceModel(name: "Localhost", ip: "127.0.0.1", port: 21)
	]
	
	@State var selectedDevice: SELDeviceModel =
	SELDeviceModel(name: "Select One", ip: "0.0.0.0", port: 21)
	
	// Validation states
	@State private var isValidDevice = true
	@State private var isValidUsername = true
	@State private var isValidPassword = true
	
	// Pipeline
	@State var apipa = ""
	@State var passivePort = 0
	
	
	var body: some View {
		
		VStack {
			// Device Selection
			VStack(alignment: .leading) {
				// Create a default selection to match with the ViewModel
				let defaultDeviceSelection = SELDeviceModel(name: "Select One", ip: "0.0.0.0", port: 21)
				
				
				// Device Model
				Text("Device Model")
				Picker("Select a Device Model", selection: $selectedDevice) {
					// Add default to List
					Text(defaultDeviceSelection.name).tag(defaultDeviceSelection)
					
					ForEach(remoteDeviceList) { device in
						Text(device.name)
							.tag(device)
							.font(.title)
							.frame(maxWidth: .infinity)
					}
				}
				.frame(height: 45.0)
				.pickerStyle(MenuPickerStyle())
				.frame(maxWidth: .infinity, alignment: .leading)
				.border(isValidDevice ? .clear : .alertMain)
				
			}
			.padding(.horizontal)
			// Divider
			Divider()
				.padding(.bottom)
				.padding(.leading)
				.padding(.trailing)
			Text("Auto discovery address: \(apipa)")
			Text("Current response: \(ftpModel.currentResponse)")
			Divider()
				.padding(.bottom)
			Text("Username")
			TextField("username", text: $username)
			
			Text("Password")
			TextField("password", text: $password)
			
			Button("Connect") {
				Task { @MainActor in
					await connectAndLogin(username: "test", password: "test")
					remoteDeviceModel.isConnected = true
				}
			}
			
			Button("Disconnect") {
				Task {
					disconnect()
				}
			}
		}.onAppear {
			//autoDiscover()
		}
	}
	
	fileprivate func send(_ str: String) {
		ftpModel.send("\(str)\r\n")
	}
	
	fileprivate func connectAndLogin(username: String, password: String) async {
		do {
			try await ftpModel.connect(device: selectedDevice)
		} catch {
			print(error.localizedDescription)
		}
		ftpModel.login(username: username, password: password)
	}
	
	fileprivate func login(username: String, password: String) {
		ftpModel.login(username: username, password: password)
	}
	
	fileprivate func disconnect() {
		
	}
		
	fileprivate func autoDiscover() {
		Task {
			while(apipa.isEmpty) {
				apipa = try await upnpModel.getRemoteDeviceIP()
			}
			if (!apipa.isEmpty && apipa.hasPrefix("169.")) {
				print(apipa)
				remoteDeviceList.append(SELDeviceModel(name: "Device Name", ip: apipa, port: 21))
			}
		}
	}
}

#Preview {
    RemoteDeviceLoginView()
}
