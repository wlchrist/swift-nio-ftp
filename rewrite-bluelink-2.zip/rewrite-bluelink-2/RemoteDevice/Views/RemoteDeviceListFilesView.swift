
import SwiftUI

struct RemoteDeviceListFilesView: View {
	@Environment(FTPModel.self) private var ftpModel
	@State var directory = ""
	var body: some View {
		VStack(alignment: .leading) {
			List {
				ForEach(ftpModel.fileList, id: \.self) { file in
					NavigationLink(value: file.name) {
						HStack {
							if file.name.contains(".") {
								Image(.textDocument)
							} else {
								Image(.folder)
							}
							VStack(alignment: .leading) {
								Text(file.name)
							}
						}
					}
				}
			}
			.navigationDestination(for: String.self, destination: { file in
				if file.contains(".") {
				RemoteDeviceFileContentView(selectedFile: file)
					.environment(ftpModel) } else {
				RemoteDeviceListFilesView(directory: file)
				.environment(ftpModel)
				.navigationBarBackButtonHidden(false)
					}
			})
		}.onAppear {
			Task {
				await getFileList(activeMode: false)
			}
		}
		
	}

	
	fileprivate func changeDirectory(_ name: String) async {
		await ftpModel.changeDirectory(folder: name)
	}
	
	//@MainActor
	fileprivate func getFileList(activeMode: Bool) async {
		await ftpModel.listFiles(activeMode: activeMode)
	}
}
