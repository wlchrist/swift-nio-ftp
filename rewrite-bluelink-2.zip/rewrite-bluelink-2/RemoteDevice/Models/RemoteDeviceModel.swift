//
//  RemoteDeviceModel.swift
//  rewrite-bluelink
//
//  Created by Warren Christian on 6/3/25.
//

import Foundation

@Observable
class RemoteDeviceModel {
	var isConnected: Bool = false
	var showRemoteDeviceBadge: String? {
		return isConnected ? "" : nil
	}
}

