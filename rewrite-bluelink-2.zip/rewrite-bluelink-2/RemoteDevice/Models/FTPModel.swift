//
//  FTPClientModel.swift
//  rewrite-bluelink
//
//  Created by Warren Christian on 6/4/25.
//

import Foundation
import SwiftUI
import NIO

@MainActor
@Observable
class FTPModel {
	
	var username = ""
	var password = ""
	var host = ""
	var port = 21
	var selectedFile = ""
	var ftpService: FTPService
	
	init(ftpService: FTPService) {
		self.ftpService = ftpService
	}
	
	var currentResponse: String {
		return ftpService.serverResponseMessage
	}
	
	var currentResponseCode: Int {
		return ftpService.serverResponseCode
	}
	
	var fileList: [FileInfo] {
		return ftpService.files
	}
	
	convenience init() {
		let ftpService = FTPService()
		self.init(ftpService: ftpService)
	}
	
	func connect(device: SELDeviceModel) async throws {
		do {
			try await ftpService.connectControlChannel(device: device)
		} catch {
			print(error.localizedDescription)
		}
	}
	
	func send(_ str: String) {
		ftpService.send(str + "\r\n")
	}
	
	func login(username: String, password: String) {
		ftpService.login(username: username, password: password)
	}
	
	func listFiles(activeMode: Bool) async {
		ftpService.currentAction = .list
		send("PASV")
	}
	
	func changeDirectory(folder: String, activeMode: Bool = false) async {
		await ftpService.changeDirectory(folder)
	}
	
	func downloadFile(_ name: String) async -> String{
		return ""
	}
}

/// Representation for individual file information.
struct FileInfo: Identifiable, Hashable {
	var id: Int {
		 return name.hashValue
	}
	
	var name: String
	
	func hash(into hasher: inout Hasher) {
		 hasher.combine(name)
	}
}
