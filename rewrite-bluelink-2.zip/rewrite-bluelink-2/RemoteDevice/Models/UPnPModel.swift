//
//  UPnPServiceModel.swift
//  rewrite-bluelink
//
//  Created by Warren Christian on 6/4/25.
//

import Foundation
import NIO

@Observable
class UPnPModel {
	private let ipDiscoveryService: IPDiscoveryService

	init(upnpService: IPDiscoveryService) {
		self.ipDiscoveryService = upnpService
	}
	
	// ip attached to iphone usb interface
	var usbIP: String {
		return ipDiscoveryService.usbIP
	}
	
	// source address of message, which is also the usb front panel ip
	var sourceAddress: String {
		return ipDiscoveryService.autoIP
	}
	
	func getRemoteDeviceIP() async throws -> String {
		do {
			try await ipDiscoveryService.getIP(waitFor: 1_000_000)
		} catch {
			print(error.localizedDescription)
		}
		return ipDiscoveryService.autoIP
	}
	
	func getResponse() -> String {
		return ipDiscoveryService.currentResponse
	}
}
