//
//  rewrite_bluelinkApp.swift
//  rewrite-bluelink
//
//  Created by Warren Christian on 6/2/25.
//

import SwiftUI

@main
struct rewrite_bluelinkApp: App {
	
	@State var showSplash = true
    var body: some Scene {
		 WindowGroup {
			 ZStack {
				 if showSplash {
					 SplashView()
				 } else {
					 MainView()
				 }
			 }.onAppear {
				 DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
					 withAnimation {
						 showSplash = false
					 }
				 }
			 }
		 }
    }
}
