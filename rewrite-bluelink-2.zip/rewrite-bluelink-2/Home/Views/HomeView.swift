//
//  HomeView.swift
//  rewrite-bluelink
//
//  Created by Warren Christian on 6/4/25.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    HomeView()
}
