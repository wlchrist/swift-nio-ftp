#  IOS Project

## Getting Started

### Xcode

Xcode is a an IDE used to build and distribute iOS, macOS, and ipadOS applications in the apple app store

#### Download link

https://developer.apple.com/download/all/?q=Xcode

### SF Symbols

This application gives an interface to locate built-in symbols and images used in iOS, macOS, and ipadOS applications design

#### Download link

https://developer.apple.com/sf-symbols/

