//
//  BlueAllyTests.swift
//  BlueAllyTests
//
//  Created by Chris Sargeant on 9/16/24.
//

import Testing

struct BlueAllyTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
