//
//  LocalFileinfoModel.swift
//  BlueAlly
//
//  Created by Warren Christian on 7/16/25.
//

import Foundation
import SwiftData

@Model
final public class LocalFileInfo {
    public var id: String {
        path
    }

    var path: String {
        url.path
    }

    @Attribute(.unique) var name: String
    var url: URL
    var size: Int
    var creationDate: Date
    var modificationDate: Date
    var isDirectory: Bool
    var folder: Folder?
    var fileExtension: String
    
    init(name: String, url: URL, size: Int, creationDate: Date, modificationDate: Date, isDirectory: Bool, folder: Folder?, fileExtension: String) {
        self.name = name
        self.url = url
        self.size = size
        self.creationDate = creationDate
        self.modificationDate = modificationDate
        self.isDirectory = isDirectory
        self.folder = folder
        self.fileExtension = fileExtension
    }
}
