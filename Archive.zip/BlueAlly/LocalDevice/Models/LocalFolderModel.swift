//
//  LocalFolderModel.swift
//  BlueAlly
//
//  Created by Warren Christian on 7/15/25.
//

import Foundation
import SwiftData

@Model
final public class Folder {
    var title: String
    @Relationship(deleteRule: .cascade, inverse: \LocalFileInfo.folder) var files: [LocalFileInfo]

    init(title: String = "", files: [LocalFileInfo]) {
          self.title = title
          self.files = files
      }
}
