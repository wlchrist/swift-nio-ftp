//
//  LocalDeviceFileListView.swift
//  BlueAlly
//
//  Created by Chris Sargeant on 9/22/24.
//

import SwiftUI
import SwiftData

struct LocalDeviceFileListView: View {
    // List of all local files
    @State var localFileInfo: [LocalFileInfo] = []
    @State var files = [""]
    @State private var selection: String?
    // Allows for directory traversal
    @State var localFilePath: URL?
    // SwiftData
    @Environment(\.modelContext) var modelContext
    @Query(sort: \LocalFileInfo.size, order: .forward)
    var localFiles: [LocalFileInfo]
    
    var body: some View {
        VStack {
            if localFiles.isEmpty {
                Text("No files found")
            }
            List(localFiles) { file in
                            NavigationLink(value: file) {
                                HStack {
                                    Image(file.isDirectory ? .folder : .textDocument)
                                    VStack(alignment: .leading) {
                                        Text(file.name)
                                        Text(
                                            file.modificationDate.formatted(
                                                date: .abbreviated,
                                                time: .complete
                                            )
                                        ).font(.caption)
                                    }
                                }
                            }
                        }
            .navigationDestination(for: LocalFileInfo.self, destination: { localFile in
                if localFile.url.isDirectory {
                    LocalDeviceFileListView()
                } else {
                    LocalDeviceFileContentView(localFilePath: localFile.path)
                        .modelContext(modelContext)
                }
            })
            .refreshable(action: loadLocalFiles)
        }
        .onAppear(perform: loadLocalFiles)
    }

    private func loadLocalFiles() {
        let fileManager = FileManager.default

        // Reset list
        localFileInfo = []

        // Get url for documents folder
        guard var documentsUrl = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else {
            fatalError()
        }

        if let localFilePath {
            documentsUrl = localFilePath
        }

        do {
            guard let filesOnDevice = try? fileManager.contentsOfDirectory(at: documentsUrl, includingPropertiesForKeys: nil, options: []) else {
                fatalError()
            }

            filesOnDevice.forEach { file in
                // Fetch file Attributes
                guard let fileAttributes = try? fileManager.attributesOfItem(atPath: file.path) else {
                    fatalError()
                }

                guard let modificationDate = fileAttributes[.modificationDate] as? Date else {
                    fatalError()
                }

                guard let creationDate = fileAttributes[.creationDate] as? Date else {
                    fatalError()
                }

                guard let size = fileAttributes[.size] as? Int else {
                    fatalError()
                }

                let fileExtension = file.path.split(separator: ".").last!

                // Append a LocalFile with attributes
                localFileInfo.append(
                    LocalFileInfo(
                        name: file.lastPathComponent,
                        url: file,
                        size: size,
                        creationDate: creationDate,
                        modificationDate: modificationDate,
                        isDirectory: file.isDirectory,
                        folder: nil,
                        fileExtension: fileExtension.lowercased()
                    )
                )
            }
        }
        
        // Sort with directories on top
        localFileInfo.sort { $0.isDirectory && !$1.isDirectory }

    }
}

#Preview {
    LocalDeviceFileListView()
}
