//
//  LocalDeviceView.swift
//
//  Created by Chris Sargeant on 9/2/24.
//

import SwiftUI
import SwiftData

struct LocalDeviceView: View {
    @Environment(\.modelContext) var modelContext
    
    var body: some View {
      NavigationStack {
        LocalDeviceFileListView()
              .modelContext(modelContext)
              .modelContainer(for: [Folder.self, LocalFileInfo.self])
      }
    }
}

#Preview {
    LocalDeviceView()
}
