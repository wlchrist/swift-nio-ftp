//
//  LocalDeviceFileContentView.swift
//  BlueAlly
//
//  Created by Chris Sargeant on 9/22/24.
//

import SwiftUI

struct LocalDeviceFileContentView: View {
    @State var localFilePath: String
    @State var localFileContent: String?

    let monospacedFont = Font.system(size: 12).monospaced()
    @Environment(\.modelContext) var modelContext
    var body: some View {
        ScrollView {
            VStack {
                Text(localFileContent ?? "Can't load file content")
                    .font(monospacedFont)
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
            }
            .padding(.horizontal)
            .navigationTitle(URL(fileURLWithPath: localFilePath).lastPathComponent)
        }
        .onAppear(perform: loadLocalFile)
        .toolbar {
            ToolbarItem {
                if let fileContent = localFileContent {
                    ShareLink(item: fileContent) {
                        Label("", systemImage: "paperplane")
                    }
                }
            }
        }
    }

    private func loadLocalFile() {
        guard FileManager.default.fileExists(atPath: localFilePath) else { return }

        // Load Content into String
        if let contents = try? String(
            contentsOf: URL(fileURLWithPath: localFilePath),
            encoding: .utf8
        ) {
            localFileContent = contents
        }
    }

}

#Preview {
    let fileManager = FileManager.default
    let documentsUrl = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!

    let testDocumentUrl = documentsUrl.appendingPathComponent("test-0.txt")
    let testDocumentContent = """
        Lorem ipsum odor amet, consectetuer adipiscing elit. Leo scelerisque hendrerit ultrices
      laoreet sed ac cursus curae. Elementum fermentum facilisi cras, fusce est fringilla fringilla.
      Urna dictumst phasellus dignissim velit auctor neque. Natoque litora laoreet malesuada nisi
      integer. Facilisi ridiculus iaculis potenti facilisi a porttitor ligula. Mus lectus cubilia
      parturient massa tortor est orci.

        Finibus faucibus at, maximus consectetur pulvinar porttitor elit. Litora neque blandit himenaeos
      tempor, adipiscing volutpat est montes. Fusce ut scelerisque cras augue per erat. Etiam consectetur
      imperdiet malesuada dui primis. Ut mauris eu lectus fames egestas habitant fames senectus.
      Sodales curae erat quisque arcu scelerisque nascetur phasellus. Posuere adipiscing habitasse erat
      habitasse suspendisse imperdiet pretium imperdiet.

        Placerat aliquet at euismod suspendisse euismod dapibus dolor suspendisse. Congue rutrum
      conubia viverra netus imperdiet. Faucibus consequat neque blandit mattis tortor enim efficitur
      habitasse. Eget dignissim ipsum congue ipsum nisi non accumsan pulvinar. Cras urna mattis
      conubia ut sodales senectus metus. Curabitur hac nibh justo dolor facilisi vel?

        Montes imperdiet interdum natoque massa semper sed. Porta sem nam integer rhoncus sagittis
      sapien et augue. Nam molestie dignissim sapien faucibus aliquet dapibus viverra donec.
      Phasellus parturient eget neque nascetur mauris. Elit libero fringilla proin est; magnis
      blandit viverra. Pharetra erat condimentum tristique class phasellus ullamcorper. Eleifend
      aenean turpis mus vitae enim magnis morbi eu. Nullam posuere felis vitae natoque sagittis.

        Iaculis senectus litora malesuada vestibulum luctus vel habitant natoque porta. Urna dictum
      odio suspendisse; dapibus sodales consectetur aliquet. Suscipit accumsan nam est ligula, duis
      rhoncus. Quisque curabitur morbi risus, sodales quisque curabitur efficitur ipsum. Litora himenaeos
      cras morbi auctor pellentesque phasellus habitant elementum. Proin viverra tellus sit praesent
      dignissim mollis. Orci conubia ad erat tellus penatibus accumsan.

        Tempus enim pharetra consectetur mollis suspendisse per auctor. Sem morbi blandit massa, nisl
      a netus arcu posuere semper. Urna consectetur aliquam platea sed sem tellus tincidunt ornare. Mollis
      neque condimentum venenatis, proin curae placerat fringilla nibh ridiculus. Dis nam nisl at habitant
      litora rhoncus cras. Montes feugiat consectetur purus quis phasellus curabitur.

        Lectus tristique mi efficitur nunc ante, et ridiculus duis. Iaculis lobortis iaculis est, facilisis
      elementum tempor. Commodo fermentum taciti id; dignissim nam a? Proin rhoncus nam dui est justo fames.
      Ornare integer mus auctor dis; eros nibh mi posuere. Litora commodo quis facilisis phasellus in habitasse.

        Accumsan sociosqu integer dis tristique; conubia tempor. Odio sed morbi; felis ornare netus quis.
      Malesuada etiam congue viverra mattis neque curae fermentum. Nullam sed ante lectus vel nullam gravida.
      Vel ultrices in viverra ante maecenas pharetra. Sapien mi quis ante habitasse molestie tristique et enim.
      Sollicitudin sagittis enim arcu feugiat vehicula.

        Accumsan ultricies parturient libero semper mattis eget. Sem massa porttitor facilisi; malesuada
      iaculis lectus. Imperdiet phasellus sem sagittis convallis vel blandit pretium eleifend congue? Ac
      aliquet ultricies nisl porta convallis metus. Suscipit penatibus dictum consectetur elementum elementum
      ac mus lectus. Id nostra auctor montes dapibus donec dolor curae tempor. Aenean in senectus nullam
      maximus sagittis; vivamus vestibulum. Adipiscing eu mi ultrices magnis laoreet congue.

        Elit aliquam a leo hendrerit finibus dui ridiculus. Imperdiet litora augue pharetra torquent a.
      Litora litora commodo non metus habitasse congue. Cursus habitant aliquet pretium sociosqu luctus tellus.
      Placerat sollicitudin felis torquent curabitur varius. Sem velit potenti taciti auctor eleifend urna
      ut vulputate. Morbi himenaeos ultricies euismod risus donec mattis sociosqu. Faucibus convallis nostra
      urna taciti nisl natoque.

        Ante dui facilisis non consectetur parturient. Vel vel eleifend dictumst sagittis phasellus quisque
      sodales tortor montes. Ullamcorper aliquam penatibus sagittis quis sociosqu nullam. Risus fringilla
      fusce faucibus ex gravida. Phasellus tincidunt sit sollicitudin penatibus class penatibus ex nulla.
      Molestie viverra natoque bibendum faucibus vestibulum aenean neque montes. Rhoncus dictumst scelerisque
      at, at iaculis pharetra mauris pulvinar. Netus malesuada ex semper viverra laoreet. Erat cras nam ex
      ligula interdum volutpat; laoreet aliquam. Varius habitant parturient pharetra vitae magna egestas
      suspendisse purus consectetur.

        Nisi amet morbi hendrerit cubilia feugiat velit felis posuere. Viverra imperdiet faucibus felis
      taciti interdum orci est sem cursus. Sollicitudin mi habitant tempus; congue hac iaculis nullam malesuada. P
      ulvinar semper pretium morbi efficitur tortor convallis feugiat. Phasellus bibendum pharetra erat auctor
      in libero; cursus et dis. Cubilia diam ex condimentum senectus lacus. In ridiculus fringilla primis parturient
      primis viverra. Risus elementum tellus nulla nullam fames elit. Nec vitae elit pulvinar nam purus bibendum.
      Penatibus tellus himenaeos nulla libero proin felis?

        Quisque fermentum torquent aenean lacus varius ullamcorper. Erat eleifend placerat ante interdum imperdiet
      tincidunt libero neque. Etiam odio cras porttitor vehicula semper mollis ante porttitor. Elit fringilla
      erat ac orci dapibus cras molestie eros sollicitudin. Scelerisque auctor adipiscing vitae habitant sed
      nascetur faucibus est. Taciti ad condimentum adipiscing netus vulputate. Dis adipiscing ex at, dignissim
      arcu ultrices morbi urna. Eget purus nascetur iaculis ante conubia quisque. Laoreet egestas est sit tempus
      curae dapibus lacinia in.

        Luctus cursus facilisis consectetur sed integer ac hendrerit magna. Mollis ut turpis montes integer cursus
      hendrerit imperdiet augue metus. Varius facilisis ultricies tempor mattis non semper habitant ligula.
      Habitasse posuere dis pretium auctor lorem ridiculus penatibus. Odio et dictum dictumst adipiscing sociosqu.
      Vel placerat posuere elit congue ipsum nisi quam. Penatibus ultricies ipsum vivamus tempor inceptos
      sodales ad sapien tristique. Ante scelerisque posuere a a ante lacus.

    """

    fileManager.createFile(
        atPath: testDocumentUrl.path,
        contents: testDocumentContent.data(using: .utf8)
    )

    return LocalDeviceFileContentView(localFilePath: testDocumentUrl.path)
}
