//
//  LocalDeviceTypes.swift
//  BlueAlly
//
//  Created by Warren Christian on 7/11/25.
//
import SwiftUI
import SwiftData

/// Representation for individual file information.
struct FileInfo: Identifiable, Hashable {
    var id: Int {
         return name.hashValue
    }
    
    var name: String
    
    func hash(into hasher: inout Hasher) {
         hasher.combine(name)
    }
}
