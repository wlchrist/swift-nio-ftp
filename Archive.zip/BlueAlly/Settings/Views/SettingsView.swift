//
//  SettingsView.swift
//  BlueAlly
//
//  Created by Chris Sargeant on 9/22/24.
//

import SwiftUI

struct SettingsView: View {
    var body: some View {
      NavigationStack {
        Text("Not Implemented Yet")
      }
    }
}

#Preview {
    SettingsView()
}
