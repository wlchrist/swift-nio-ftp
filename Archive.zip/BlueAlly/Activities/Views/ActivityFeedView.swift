//
//  ActivityFeedView.swift
//  BlueAlly
//
//  Created by Warren Christian on 7/16/25.
//

import SwiftUI
import SwiftData

struct ActivityFeedView: View {
    @Environment(\.modelContext) var modelContext
    @State var activities: [Activity] = []
    var body: some View {
        VStack {
            List(activities) { activity in
                NavigationLink(value: activity) {
                                HStack {
                                    Text("")
                                }
                            }
                        }
        }
    }
}

#Preview {
    ActivityFeedView()
}
