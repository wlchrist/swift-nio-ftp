//
//  ActivityModel.swift
//  BlueAlly
//
//  Created by Warren Christian on 7/16/25.
//

import Foundation
import SwiftData


@Model
final public class Activity {
    var didRead: Bool
    var didWrite: Bool
    var file: LocalFileInfo?
    
    init(didRead: Bool, didWrite: Bool, file: LocalFileInfo? = nil) {
        self.didRead = didRead
        self.didWrite = didWrite
        self.file = file
    }
}

