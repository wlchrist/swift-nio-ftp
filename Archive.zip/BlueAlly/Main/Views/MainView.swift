//
//  MainView.swift
//
//  Created by Chris Sargeant on 9/2/24.
//

import SwiftUI
import SwiftData

struct MainView: View {
    @State private var remoteDeviceModel = RemoteDeviceClient()
    @Environment(\.modelContext) var modelContext
    init() {
        // Modify the badge Color
        UITabBarItem.appearance().badgeColor = .green
    }
    
    var body: some View {
        TabView {
            HomeView()
                .tabItem { Label("Home", image: .home) }
            LocalDeviceView()
                .tabItem { Label("Files", image: .folder) }
                .modelContext(modelContext)
            RemoteDeviceView()
                .tabItem { Label("Device", image: .protectionDevice) }
                .environment(remoteDeviceModel)
                .modelContext(modelContext)
                .badge(remoteDeviceModel.showRemoteDeviceBadge)
            SettingsView()
                .tabItem { Label("Settings", image: .settings) }
        }
    }
}

#Preview {
    MainView()
}
