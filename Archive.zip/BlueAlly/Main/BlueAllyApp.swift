//
//
//  Created by Chris Sargeant on 9/2/24.
//

import SwiftUI
import SwiftData

@main
struct BlueAllyApp: App {
    @State var showSplash: Bool = true
        
    var body: some Scene {
        WindowGroup {
            ZStack {
                if showSplash {
                    SplashView()
                } else {
                    MainView()
                        .modelContainer(for: LocalFileInfo.self)
                        .modelContainer(for: Activity.self)
                }
            }.onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    withAnimation {
                        showSplash = false
                    }
                }
            }
        }
    }
}
