//
//  SELDeviceModel.swift
//  rewrite-bluelink
//
//  Created by Warren Christian on 6/4/25.
//

struct SELDevice: Identifiable, Hashable {
	 var id: Int {
		  return name.hashValue
	 }

	 let name: String
	 var ip: String
	 let port: Int

	 func hash(into hasher: inout Hasher) {
		  hasher.combine(name)
	 }
}
