//
//  RemoteDeviceFileContentView.swift
//  BlueAlly
//
//  Created by Warren Christian on 9/26/24.
//

import SwiftUI
import SwiftData

struct RemoteDeviceFileContentView: View {
    @Environment(FTPController.self) private var ftpModel
    // File selection
    @State var selectedFile: String
    
    // Alerts
    @State private var alertIsPresented: Bool = false
    @State private var alertMessage: String?
    @State private var alertTitle: String?
    
    // SwiftData
    @Environment(\.modelContext) var modelContext
    
    var body: some View {
        ScrollView {
            VStack {
                Text(ftpModel.viewFileContent)
                    .multilineTextAlignment(.leading)
                    .font(Font.system(size: 12).monospaced())
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
            }
            .padding(.horizontal)
            .navigationTitle(selectedFile)
        }.onAppear {
            // Load file
            Task {
                await readFile(selectedFile, activeMode: false)
            }
        }
        .toolbar {
            ToolbarItem {
                Button(action: saveFile) {
                    Image(systemName: "square.and.arrow.down")
                }.alert("Saved!", isPresented: $alertIsPresented) {
                    Button("OK", role: .cancel) { alertIsPresented = false }
                } message: {
                    Text(alertMessage ?? "")
                }
                
            }
        }
    }
    
    fileprivate func readFile(_ name: String, activeMode: Bool) async {
        ftpModel.selectedFile.name = selectedFile
        Task {
            await ftpModel.downloadFile(name, activeMode: activeMode) // downloading to read
        }
    }
    
    fileprivate func saveFile() {
        let fileManager = FileManager.default
        let documentsDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        let outputFileName = documentsDirectory.appendingPathComponent(selectedFile)
        
        do {
            // save to file manager
            try ftpModel.viewFileContent.write(to: outputFileName, atomically: true, encoding: .utf8)
            alertMessage = "\(selectedFile) saved successfully"
            alertTitle = "Saved!"
            alertIsPresented = true
            print("Wrote file \(outputFileName.path)")
            
            let attributes = try FileManager.default.attributesOfItem(atPath: outputFileName.path) // grabbing attributes for model
            // create a localfile model to be inserted
            let localFile = LocalFileInfo(
                name: selectedFile,
                url: outputFileName.absoluteURL,
                size: attributes[.size] as! Int,
                creationDate: attributes[.creationDate] as! Date,
                modificationDate: attributes[.modificationDate] as! Date,
                isDirectory: false,
                folder: attributes[.type] as? Folder,
                fileExtension: attributes[.type] as! String
            )
            modelContext.insert(localFile)
        } catch {
            alertMessage = "Could not write to file \(selectedFile)"
            alertTitle = "Error"
            alertIsPresented = true
            
            print("Could not write to file \(outputFileName.path): \(error)")
        }
    }
}


#Preview {
    @Previewable @State var ftpController = FTPController()
    RemoteDeviceFileContentView(selectedFile: "")
        .environment(ftpController)
}
