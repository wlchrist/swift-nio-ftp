//
//  RemoteDeviceView.swift
//
//  Created by Chris Sargeant on 9/2/24.
//

import SwiftUI
import SwiftData

struct RemoteDeviceView: View {
    @State private var ftpModel = FTPController()
    @State private var upnpModel = UPNPController(client: IPDiscoveryClient())
    @Environment(RemoteDeviceClient.self) private var remoteDeviceModel
    
    // SwiftData
    @Query var files: [LocalFileInfo]
    @Environment(\.modelContext) var modelContext
    
    @State private var mode = 0
    
    var body: some View {
        NavigationStack {
            VStack {
                if self.remoteDeviceModel.isConnected {
                    // TODO Switch to a local list if mode is send
                    RemoteDeviceListFilesView()
                        .environment(ftpModel)
                        .environment(remoteDeviceModel)
                        .modelContext(modelContext)
                } else {
                    RemoteDeviceLoginView()
                        .environment(ftpModel)
                        .environment(upnpModel)
                        .environment(remoteDeviceModel)
                }
            }.toolbar {
                // Add disconnect button to toolbar
                ToolbarItem {
                    if remoteDeviceModel.isConnected {
                        Button(action: disconnectFromDevice) {
                            Image(systemName: "network.slash")
                        }
                    }
                }
                // Add Picker for mode
                ToolbarItem(placement: .principal) {
                    if remoteDeviceModel.isConnected {
                        Picker("Mode", selection: $mode) {
                            Text("Read").tag(0)
                            Text("Send").tag(1)
                        }
                        .pickerStyle(.segmented)
                    }
                }
            }
        }
    }
    
    private func disconnectFromDevice() {
        remoteDeviceModel.isConnected = false
        
        // TODO: disconnect
    }
    
}

@MainActor
@Observable
public class FTPController {
    
    var username = ""
    var password = ""
    var host = ""
    var port = 21
    var selectedFile = FileInfo(name: "")
    var ftpService: FTPClient
    
    init(ftpService: FTPClient) {
        self.ftpService = ftpService
    }
    
    var currentResponseString: String {
        return ftpService.serverResponseMessage
    }
    
    var currentResponseCode: Int {
        return ftpService.serverResponseCode
    }
    
    var fileList: [FileInfo] {
        return ftpService.files
    }
    
    var viewFileContent: String {
        return ftpService.viewFileContent
    }
    
    convenience init() {
        let ftpService = FTPClient()
        self.init(ftpService: ftpService)
    }
    
    func connect(device: SELDevice) async throws {
        do {
            try await ftpService.connectControlChannel(device: device)
        } catch {
            print(error.localizedDescription)
        }
    }
    
    func send(_ str: String) {
        ftpService.send(str + "\r\n")
    }
    
    func login(username: String, password: String) {
        ftpService.login(username: username, password: password)
    }
    
    func listFiles(activeMode: Bool) async {
        ftpService.currentAction = .list
        send("PASV")
    }
    
    func changeDirectory(folder: String, activeMode: Bool = false) {
        ftpService.requestedFile = folder
        send("CWD \(folder)")
    }
    
    func downloadFile(_ name: String, activeMode: Bool) async {
        ftpService.currentAction = .download
        ftpService.requestedFile = name
        print(name)
        if !activeMode {
            send("PASV")
        }
    }
}

@Observable
public class UPNPController {
    private let ipDiscoveryService: IPDiscoveryClient

    init(client: IPDiscoveryClient) {
        self.ipDiscoveryService = client
    }
    
    // ip attached to iphone usb interface
    var usbIP: String {
        return ipDiscoveryService.usbIP
    }
    
    // source address of message, which is also the usb front panel ip
    var sourceAddress: String {
        return ipDiscoveryService.autoIP
    }
    
    func getRemoteDeviceIP() async throws -> String {
        do {
            try await ipDiscoveryService.getIP(waitFor: 1_000_000)
        } catch {
            print(error.localizedDescription)
        }
        return ipDiscoveryService.autoIP
    }
    
    func getResponse() -> String {
        return ipDiscoveryService.currentResponse
    }
}

#Preview {
    RemoteDeviceView()
        .environment(RemoteDeviceClient())
}
