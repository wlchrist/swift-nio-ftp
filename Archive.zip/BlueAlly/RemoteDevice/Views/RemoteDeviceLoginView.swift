//
//  RemoteDeviceLoginView.swift
//  BlueAlly
//
//  Created by Chris Sargeant on 9/15/24.
//

import SwiftUI

struct RemoteDeviceLoginView: View {
    
    // Models
    @Environment(FTPController.self) private var ftpModel
    @Environment(UPNPController.self) private var upnpModel
    @Environment(RemoteDeviceClient.self) private var remoteDeviceModel
    
    // List of devices for the user to pick from
    var remoteDeviceList: [SELDevice] = [
        SELDevice(name: "9 Series", ip: "192.168.1.20", port: 21),
        SELDevice(name: "Localhost", ip: "127.0.0.1", port: 21)
    ]
    
    @State var selectedDevice: SELDevice =
    SELDevice(name: "Select One", ip: "0.0.0.0", port: 21)
    
    // Login information
    @State var username: String = ""
    @State var password: String = ""
    
    // Validation states
    @State private var isValidDevice = true
    @State private var isValidUsername = true
    @State private var isValidPassword = true
    
    var body: some View {
        VStack {
            // Device Selection
            VStack(alignment: .leading) {
                // Create a default selection to match with the ViewModel
                let defaultDeviceSelection = SELDevice(name: "Select One", ip: "0.0.0.0", port: 21)
                
                // Device Model
                Text("Device Model")
                Picker("Select a Device Model", selection: $selectedDevice) {
                    // Add default to List
                    Text(defaultDeviceSelection.name).tag(defaultDeviceSelection)
                    
                    ForEach(remoteDeviceList) { device in
                        Text(device.name)
                            .tag(device)
                            .font(.title)
                            .frame(maxWidth: .infinity)
                    }
                }
                .frame(height: 45.0)
                .pickerStyle(MenuPickerStyle())
                .frame(maxWidth: .infinity, alignment: .leading)
                .border(isValidDevice ? .clear : .alertMain)
                
            }
            .padding(.horizontal)
            
            // Divider
            Divider()
                .padding(.bottom)
                .padding(.leading)
                .padding(.trailing)
            
            // Username
            VStack(alignment: .leading) {
                Text("Username")
                TextField("", text: $username)
                    .autocorrectionDisabled(true)
                    .textInputAutocapitalization(.never)
                    .font(.title)
                    .fontWeight(.light)
                    .border(isValidUsername ? .greyContrastMain : .alertMain)
                    .textFieldStyle(.roundedBorder)
                
            }.padding(.horizontal)
            
            // Password
            VStack(alignment: .leading) {
                Text("Password")
                SecureField("", text: $password)
                    .font(.title)
                    .fontWeight(.light)
                    .border(isValidPassword ? .greyContrastMain : .alertMain)
                    .textFieldStyle(.roundedBorder)
                
            }.padding(.horizontal)
            
            // Connect Button
            Button(action: connectToRemoteDevice) {
                Text("Connect")
                    .font(.title2)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .tint(.primaryMain)
            .padding()
        }
    }
    
    private func connectToRemoteDevice() {
        guard validateLoginFields() else { return }
        
        // Connect to remote device
        Task { @MainActor in
            do {
                try await ftpModel.connect(device: selectedDevice)
            } catch {
                print(error.localizedDescription)
            }
            ftpModel.login(username: username, password: password)
            remoteDeviceModel.isConnected = true
        }
    }
    
    private func validateLoginFields() -> Bool {
        (isValidDevice,isValidUsername,isValidPassword) = (true,true,true)
        
        // Check if default device is currently selected
        if selectedDevice.ip == "0.0.0.0" { isValidDevice = false }
        
        // Check if username is blank
        if username.isEmpty { isValidUsername = false }
        
        // Check if password is blank
        if password.isEmpty { isValidPassword = false }
        
        // if any variable is false return false
        guard isValidDevice && isValidUsername && isValidPassword else {
            return false
        }
        
        // Default
        return true
    }
}

#Preview {
    RemoteDeviceLoginView()
        .environment(FTPController())
        .environment(UPNPController(client: IPDiscoveryClient()))
        .environment(RemoteDeviceClient())
}
