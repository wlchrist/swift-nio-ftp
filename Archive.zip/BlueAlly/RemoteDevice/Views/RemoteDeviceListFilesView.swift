//
//  RemoteDevicesListFiles.swift
//
//  Created by Chris Sargeant on 9/2/24.
//

import SwiftUI
import SwiftData

struct RemoteDeviceListFilesView: View {
    @Environment(FTPController.self) private var ftpModel
    @State var directory = "/"
    
    // SwiftData
    @Environment(\.modelContext) var modelContext
    
    var body: some View {
        VStack(alignment: .leading) {
            List {
                ForEach(ftpModel.fileList, id: \.self) { file in
                    NavigationLink(value: file.name) {
                        HStack {
                            if file.name.contains(".") {
                                Image(.textDocument)
                            } else {
                                Image(.folder)
                            }
                            VStack(alignment: .leading) {
                                Text(file.name)
                            }
                        }
                    }
                }
            }
            .navigationDestination(for: String.self, destination: { file in
                if file.contains(".") {
                    RemoteDeviceFileContentView(selectedFile: file)
                        .environment(ftpModel)
                        .modelContext(modelContext)
                } else {
                    RemoteDeviceListFilesView(directory: file)
                        .environment(ftpModel)
                        .navigationBarBackButtonHidden(false)
                }
            })
        }
        .onAppear {
            Task {
                await getFileList(activeMode: false)
            }
        }
    }
    fileprivate func getFileList(activeMode: Bool) async {
        await ftpModel.listFiles(activeMode: activeMode)
    }
    
    fileprivate func changeDirectory(_ changeTo: String) {
        ftpModel.changeDirectory(folder: changeTo)
    }
    
}

#Preview {
    @Previewable @State var ftpModel = FTPController()
    
    // Display View
    RemoteDeviceListFilesView(directory: "")
        .environment(ftpModel.self)
}

