//
//  RemoteDeviceModel.swift
//  rewrite-bluelink
//
//  Created by Warren Christian on 6/3/25.
//

import Foundation

// Just keeps track of connection state for presenting the device badge
@Observable
class RemoteDeviceClient {
	var isConnected: Bool = false
	var showRemoteDeviceBadge: String? {
		return isConnected ? "" : nil
	}
}

