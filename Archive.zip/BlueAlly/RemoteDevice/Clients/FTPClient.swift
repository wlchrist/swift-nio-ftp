//
//  NIO.swift
//  rewrite-bluelink
//
//  Created by Warren Christian on 6/2/25.
//

import Foundation
import SwiftUI
import NIO
import RegexBuilder

/// Stores data for our pipeline before bootstrapping the the connection. Using convenience initializers, as this separates concerns
/// Should not be thought of as distinct from service, but rather, a dependency required for our service to execute properly
@Observable
final class PipelineManager {
	
	var eventLoop: MultiThreadedEventLoopGroup
	var controlBootstap: ClientBootstrap
	var dataBootstrap: ClientBootstrap
	var currentMessage: String
	var currentResponseCode: Int
	var files: [FileInfo]
	var fileContent: String
	
	init(eventLoop: MultiThreadedEventLoopGroup,
         controlBootstrap: ClientBootstrap,
         dataBootstrap: ClientBootstrap,
         currentMessage: String,
         currentResponseCode: Int,
         files: [FileInfo],
         fileContent: String) {
		self.eventLoop = eventLoop
		self.controlBootstap = controlBootstrap
		self.dataBootstrap = dataBootstrap
		self.currentMessage = currentMessage
		self.currentResponseCode = currentResponseCode
		self.files = files
		self.fileContent = fileContent
	}
	
	convenience init() {
		let eventLoop = MultiThreadedEventLoopGroup(numberOfThreads: System.coreCount)
		let controlBootstrap = ClientBootstrap(group: eventLoop)
		let dataBootstrap = ClientBootstrap(group: eventLoop)
		let currentMessage = ""
		let currentResponseCode = 0
		let files = [FileInfo(name: "")]
		let fileContent = ""
		self.init(eventLoop: eventLoop, controlBootstrap: controlBootstrap, dataBootstrap: dataBootstrap, currentMessage: currentMessage, currentResponseCode: currentResponseCode, files: files, fileContent: fileContent)
	}
	
	 internal func responseCodeEmitter(responseCode: Int) {
		print("Response from remote: \(responseCode)")
	}
}

/// Creates an instance of `PipelineManager`
/// Responsible for starting the connection and keeping track of FTP-specific details, such as logins, response code dispatching, and creating both the control and data channel
/// Data channels are separated into their respective use-case since they are closed by the FTP server once a successful data retreival event has completed, as opposed to
/// firing off the next handler in the pipeline, since we are consuming channels
@preconcurrency
final class FTPClient: @unchecked Sendable {
	
	var host: String?
	var port: Int?
	var pipelineManager = PipelineManager()
	var controlChannel: Channel?
	var dataChannel: Channel?
	var currentAction: UserAction = .idle
	lazy var requestedFile = String()
    lazy var changeDirTo = String()
	
	var serverResponseMessage: String {
		return pipelineManager.currentMessage
	}
	var serverResponseCode: Int {
		return pipelineManager.currentResponseCode
	}
	var files: [FileInfo] {
		return pipelineManager.files
	}
	var viewFileContent: String {
		return pipelineManager.fileContent
	}
	
	func login(username: String, password: String) {
		send("USER \(username)\r\n")
		send("PASS \(password)\r\n")
	}
	
	func connectControlChannel(device: SELDevice) async throws {
		self.host =  device.ip
		self.port =  device.port
		controlChannel = try await pipelineManager.controlBootstap.channelInitializer { [self] channel in
			channel.pipeline.addHandlers([
				ChannelReadHandler(manager: pipelineManager, service: self)
			])
		}.connect(host: self.host ?? "", port: self.port ?? 21).get()
	}
	
	func connectListChannel(_ passivePort: Int?) async throws {
		do {
			dataChannel = try await pipelineManager.dataBootstrap.channelInitializer { [self] channel in
				channel.pipeline.addHandlers([
					FileListReadHandler(manager: pipelineManager)
				])
			}.connect(host: self.host ?? "", port: passivePort ?? 21).get()
		} catch {
			print(error.localizedDescription)
		}
	}
	
	func connectDownloadChannel(_ passivePort: Int?) async throws {
		do {
			dataChannel = try await pipelineManager.dataBootstrap.channelInitializer { [self] channel in
				channel.pipeline.addHandlers([
					DownloadHandler(manager: pipelineManager, service: self)
				])
			}.connect(host: self.host ?? "", port: passivePort ?? 21).get()
		} catch {
			print(error.localizedDescription)
		}
	}
	
	// Message queue for rate limiting
	func send(_ str: String) {
        struct State {
             nonisolated(unsafe) static var queue: [String] = []
             nonisolated(unsafe) static var isSending = false
			 static let sendInterval: TimeAmount = .milliseconds(150)
		 }

		 State.queue.append(str)
		
		@Sendable
		func processQueue() {
			  guard !State.isSending, !State.queue.isEmpty else { return }
			  State.isSending = true
			  let nextMessage = State.queue.removeFirst()
			  let strBuff = ByteBuffer(string: nextMessage)
			  Task { @MainActor in
					controlChannel?.writeAndFlush(strBuff).whenComplete { _ in
						self.controlChannel?.eventLoop.scheduleTask(in: State.sendInterval) {
							  State.isSending = false
							  processQueue()
						 }
					}
			  }
		 }
		 processQueue()
	}
}

final class ChannelReadHandler: ChannelInboundHandler, @unchecked Sendable {
		var manager: PipelineManager
		var service: FTPClient
		
		init(manager: PipelineManager, service: FTPClient) {
			self.manager = manager
			self.service = service
		}
		
		public typealias InboundIn = ByteBuffer
		public typealias InboundOut = ByteBuffer
		public typealias OutboundOut = ByteBuffer
		
		private func getResponseCode(_ from: String) -> Int {
			return from.components(separatedBy: " ").compactMap{Int($0)}[0]
		}
		
		func channelActive(context: ChannelHandlerContext) {
			print("Remote peer connected: \(context.remoteAddress?.ipAddress ?? "")")
			print("Port: \(context.remoteAddress?.port ?? 0)")
		}
    
		func channelRead(context: ChannelHandlerContext, data: NIOAny) {
			let inBuff = unwrapInboundIn(data)
			guard let str = inBuff.getString(at: 0, length: inBuff.readableBytes) else {return}
			let responseCode = getResponseCode(str)
            print(str)
			manager.responseCodeEmitter(responseCode: responseCode)
            manager.currentResponseCode = getResponseCode(str)
			manager.currentMessage = str
			actionInvoker(responseCode: responseCode, action: service.currentAction)
		}
		
	// State machine for invoking actions on our `EventLoop`
	@Sendable
    func actionInvoker(responseCode: Int, action: UserAction) {
        enum List: Int {
            case passive = 227
            case fileStatusOK = 150
        }
        enum Download: Int {
            case passive = 227
            case fileStatusOK = 150
        }
        enum ChangeDirectory: Int {
            case fileStatusOK = 150
        }
			
			if action == .list {
				switch List(rawValue: responseCode) {
				case .passive:
					Task { @MainActor in
						do {
							try await service.connectListChannel(passivePortCalculator(manager.currentMessage))
						} catch {
							print(error.localizedDescription)
						}
					}
					service.send("NLST\r\n")
				case .fileStatusOK:
					break
				default:
					break
				}
			}
			if action == .download {
				switch Download(rawValue: responseCode) {
				case .passive:
                    Task { @MainActor in
						do {
							try await service.connectDownloadChannel(passivePortCalculator(manager.currentMessage))
						} catch {
							print(error.localizedDescription)
						}
					}
					service.send("RETR \(service.requestedFile)\r\n")
				case .fileStatusOK:
					break
				default:
					break
				}
			}
        if action == .cwd {
            switch ChangeDirectory(rawValue: responseCode) {
            case .fileStatusOK:
                service.send("CWD \(service.changeDirTo)\r\n")
            default:
                break
            }
        }
			
		}
	}

final class FileListReadHandler: ChannelInboundHandler, @unchecked Sendable {
	public typealias InboundIn = ByteBuffer
	public typealias Inboundout = ByteBuffer
	
	var currentString = ""
	var manager: PipelineManager
	
	init(manager: PipelineManager) {
		self.manager = manager
	}
	
	func channelActive(context: ChannelHandlerContext) {
		print("Channel active on: \(context.remoteAddress?.port ?? 0)")
	}
	
	func channelRead(context: ChannelHandlerContext, data: NIOAny) {
		let inBuff = unwrapInboundIn(data)
		guard let str = inBuff.getString(at: 0, length: inBuff.readableBytes) else {return}
		currentString.append(contentsOf: str)
		manager.files = buildFileStruct(str)
		print(str)
	}
	
	// Takes in raw string output of a "LIST" command and returns a list of `FileInfo` structs
	fileprivate func buildFileStruct(_ listOutput: String) -> [FileInfo] {
		var fileInfoArr = [FileInfo]()
		let fileListRegex = FileListInfo()
		
		for file in fileListRegex.fileListPattern(listOutput) {
			fileInfoArr.append(FileInfo(name: file))
			
		}
		return fileInfoArr
	}
}

final class DownloadHandler: ChannelInboundHandler {
	public typealias InboundIn = ByteBuffer
	public typealias InboundOut = ByteBuffer
    let manager: PipelineManager
    let service: FTPClient
	
	init(manager: PipelineManager, service: FTPClient) {
		self.manager = manager
		self.service = service
	}
	
	nonisolated func channelActive(context: ChannelHandlerContext) {
		print("Channel active on: \(context.remoteAddress?.port ?? 0)")
	}
	
	nonisolated func channelRead(context: ChannelHandlerContext, data: NIOAny) {
		let inBuff = unwrapInboundIn(data)
		guard let str = inBuff.getString(at: 0, length: inBuff.readableBytes) else {return}
        clearFileContent() // making sure we're not presenting previous file content to user
        if !str.isEmpty {
            manager.fileContent.append(str)
        }
        print(str)
	}
    
    nonisolated func clearFileContent() {
        if !manager.fileContent.isEmpty {
            manager.fileContent.removeAll()
        }
    }
}

public func passivePortCalculator(_ serverResponse: String) throws -> Int {
	let defaultPort = 20
	guard let port = try? /\(.*\)/.firstMatch(in: serverResponse)?
		.output.replacingOccurrences(of: "[()]", with: "", options: [.regularExpression])
		.components(separatedBy: ",") else {return defaultPort}
	
	let passiveOctets = port.suffix(2).compactMap { Int($0) }
	return passiveOctets[0] * 256 + passiveOctets[1]
}

struct FileListInfo {
	func fileListPattern(_ input: String) -> [String] {
		var fileList = [String]()
		let fileFolderRegex =
		Regex {
			TryCapture {
				/(?m)([\w.:-]+$)/
			} transform: {
				String($0)
			}
		}
		let matches = input.matches(of: fileFolderRegex)
		for match in matches {
			fileList.append(match.output.1)
		}
		return fileList
	}
	func filePermissionsPattern(_ input: String) -> [String] {
		var fileList = [String]()
		let fileFolderRegex =
		Regex {
			TryCapture {
				/(?m)(^[drw-]+)/
			} transform: {
				String($0)
			}
		}
		let matches = input.matches(of: fileFolderRegex)
		for match in matches {
			fileList.append(match.output.1)
		}
		return fileList
	}
}

enum UserAction {
	case idle
	case list
	case download
    case cwd
	case disconnect
}
