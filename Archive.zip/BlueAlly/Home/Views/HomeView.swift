//
//  HomeView.swift
//
//  Created by Chris Sargeant on 9/2/24.
//

import SwiftUI

struct HomeView: View {
    @State private var mode: Int = 0
    
    var body: some View {
        NavigationStack {
            
            VStack {
                // TODO: Implement Favorites and Recent list
                LocalDeviceFileListView()
            }
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Picker("Mode", selection: $mode) {
                        Text("📄 Recent").tag(0)
                        Text("★ Favorites").tag(1)
                    }
                    .pickerStyle(.segmented)
                }
            }
        }
    }
}

#Preview {
    HomeView()
}
